Important:

1: Move the folders "config", "resources" and "scripts" to your modded .minecraft instance. Override EVERYTHING it asks for
2:CHANGELOG.txt is not up to date
3: Mods not included that I've been using for testing purposes:
	Efortlesbuilding 2.16
	Farlanders 1.0.1
	BlockDropsTweaker-1.12.2-2.4
	malisiscore-1.12.2-6.5.1
	malisisdoors-1.12.2-7.3.0 (There's a crafting script for this mod bundled with the rest already)
4: Some supposedly removed recipes aren't. Need to fix